import { useState } from "react";
import TeamHeader from "./TeamHeader";
import NextGameCard from "./NextGameCard";
import RosterTable from "./RosterTable";
import PlayerDetail from "./PlayerDetail";
import { mockTeam, mockPlayers } from "../data/mockPlayers";

export default function Dashboard() {
  // useState nos da dos cosas:
  // 1. selectedPlayerId -> el valor actual (arranca en null, nadie seleccionado)
  // 2. setSelectedPlayerId -> la única forma "correcta" de cambiar ese valor.
  // Cuando llamamos a setSelectedPlayerId, React vuelve a renderizar
  // el Dashboard (y todo lo que dependa de selectedPlayerId) con el nuevo valor.
  const [selectedPlayerId, setSelectedPlayerId] = useState(null);

  // Derivamos el objeto jugador a partir del id guardado en el estado.
  // No guardamos el objeto completo en el estado para evitar tener
  // dos "fuentes de verdad" (el id en el estado + el objeto en mockPlayers).
  const selectedPlayer = mockPlayers.find((p) => p.id === selectedPlayerId) ?? null;

  return (
    <div className="max-w-6xl mx-auto px-6 py-10">
      <TeamHeader team={mockTeam} />

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-start">
        <div className="md:col-span-1 flex flex-col gap-6">
          <NextGameCard game={mockTeam.nextGame} />
          <PlayerDetail
            player={selectedPlayer}
            onClose={() => setSelectedPlayerId(null)}
          />
        </div>
        <div className="md:col-span-2">
          <RosterTable
            players={mockPlayers}
            selectedId={selectedPlayerId}
            onSelectPlayer={setSelectedPlayerId}
          />
        </div>
      </div>
    </div>
  );
}
