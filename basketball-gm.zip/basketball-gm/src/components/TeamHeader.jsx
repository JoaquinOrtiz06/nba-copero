export default function TeamHeader({ team }) {
  const { name, city, record, conferenceRank, salaryCap, salaryUsed } = team;
  const capPct = Math.round((salaryUsed / salaryCap) * 100);

  return (
    <header className="border-b border-court-700 pb-6 mb-8 flex flex-wrap items-end justify-between gap-6">
      <div>
        <p className="font-mono text-xs tracking-[0.2em] text-court-400 uppercase mb-1">
          {city} · #{conferenceRank} en la Conferencia
        </p>
        <h1 className="font-display text-4xl md:text-5xl uppercase tracking-wide text-court-200">
          {name}
        </h1>
      </div>

      <div className="flex items-end gap-8">
        <div>
          <p className="font-mono text-xs text-court-400 uppercase mb-1">Récord</p>
          <p className="font-display text-3xl">
            <span className="text-win">{record.wins}</span>
            <span className="text-court-600 mx-1">–</span>
            <span className="text-loss">{record.losses}</span>
          </p>
        </div>

        <div className="min-w-[160px]">
          <p className="font-mono text-xs text-court-400 uppercase mb-1">
            Tope salarial · {capPct}%
          </p>
          <div className="h-2 rounded-full bg-court-800 overflow-hidden">
            <div
              className="h-full bg-scoreboard rounded-full transition-all"
              style={{ width: `${capPct}%` }}
            />
          </div>
          <p className="font-mono text-xs text-court-400 mt-1">
            ${salaryUsed}M / ${salaryCap}M
          </p>
        </div>
      </div>
    </header>
  );
}
