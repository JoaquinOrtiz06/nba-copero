export default function RosterTable({ players, selectedId, onSelectPlayer }) {
  return (
    <div className="bg-court-900 border border-court-700 rounded-xl overflow-hidden">
      <div className="px-6 py-4 border-b border-court-700">
        <h2 className="font-display text-xl uppercase tracking-wide text-court-200">
          Plantilla
        </h2>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left font-mono text-xs text-court-400 uppercase border-b border-court-700">
              <th className="px-6 py-3 font-medium">Jugador</th>
              <th className="px-3 py-3 font-medium">Pos</th>
              <th className="px-3 py-3 font-medium">Edad</th>
              <th className="px-3 py-3 font-medium">OVR</th>
              <th className="px-3 py-3 font-medium">Min</th>
              <th className="px-3 py-3 font-medium">Pts</th>
              <th className="px-3 py-3 font-medium">Reb</th>
              <th className="px-3 py-3 font-medium">Ast</th>
              <th className="px-6 py-3 font-medium">Salario</th>
            </tr>
          </thead>
          <tbody>
            {players.map((p) => (
              <tr
                key={p.id}
                onClick={() => onSelectPlayer(p.id)}
                className={
                  "border-b border-court-800 last:border-0 hover:bg-court-800/50 transition-colors cursor-pointer " +
                  (selectedId === p.id ? "bg-court-800" : "")
                }
              >
                <td className="px-6 py-3">
                  <div className="flex items-center gap-2">
                    <span className="text-court-200">{p.name}</span>
                    {p.status === "injured" && (
                      <span className="w-1.5 h-1.5 rounded-full bg-loss" title="Lesionado" />
                    )}
                  </div>
                </td>
                <td className="px-3 py-3 text-court-400">{p.pos}</td>
                <td className="px-3 py-3 text-court-400">{p.age}</td>
                <td className="px-3 py-3">
                  <span
                    className={
                      p.ovr >= 85 ? "text-scoreboard font-semibold" : "text-court-200"
                    }
                  >
                    {p.ovr}
                  </span>
                </td>
                <td className="px-3 py-3 font-mono text-court-400">{p.minutes}</td>
                <td className="px-3 py-3 font-mono text-court-200">{p.stats.pts}</td>
                <td className="px-3 py-3 font-mono text-court-200">{p.stats.reb}</td>
                <td className="px-3 py-3 font-mono text-court-200">{p.stats.ast}</td>
                <td className="px-6 py-3 font-mono text-court-400">${p.salary}M</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
